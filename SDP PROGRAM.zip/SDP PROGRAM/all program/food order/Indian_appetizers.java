public class Indian_appetizers implements appetizers{
    public String create_appetizers()
    {
        return "create Indian appetizers dish";
    }
}
