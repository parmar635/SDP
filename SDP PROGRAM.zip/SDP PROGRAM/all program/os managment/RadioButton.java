public interface RadioButton <T>{
    public String createRadioButton();
}
