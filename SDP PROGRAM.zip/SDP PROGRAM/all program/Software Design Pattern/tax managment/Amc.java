public class Amc implements PropertyTax,WaterTax {
    public void  CalculateTax()
    {
        System.out.println("amc taxcalculate");
    }
}
