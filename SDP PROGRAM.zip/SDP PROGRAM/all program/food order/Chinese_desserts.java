public class Chinese_desserts implements desserts {
    public String Create_desserts()
    {
        return "create Chinese desserts dish";
    }
}
