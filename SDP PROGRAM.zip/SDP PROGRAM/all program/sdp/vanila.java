public class vanila {
    public String valina_icecream;
    public vanila()
    {
        valina_icecream="valina ice-cream";
    }
    public double getcost()
    {
        return 0.0;
    }
    public String getdescription()
    {
        return valina_icecream;
    }
}
