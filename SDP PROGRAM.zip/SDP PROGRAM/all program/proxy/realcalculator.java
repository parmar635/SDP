public class realcalculator implements proxycal {
    public double sumofnum(double v1,double v2)
    {
        return v1+v2;
    }
}
