public interface checkbox <T>{
    public String createcheckbox();
}
