public interface proxycal {
public double sumofnum(double v1,double v2);
}