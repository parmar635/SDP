public interface Ice_cream {
public double getcost();
public String getdescription();   
}
