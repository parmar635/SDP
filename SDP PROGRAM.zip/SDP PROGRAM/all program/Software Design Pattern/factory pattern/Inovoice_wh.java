public class Inovoice_wh implements Inovoice{
    String Itype;
   
   public Inovoice_wh()
   {
    Itype="Inovoice without header..";
   }
   public String getInovoice()
   {
      return Itype;
   }
}
