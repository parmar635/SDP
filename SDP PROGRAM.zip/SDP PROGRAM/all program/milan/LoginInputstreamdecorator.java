import java.io.IOException;
import java.io.InputStream;

public abstract class LoginInputstreamdecorator extends InputStream {
   public InputStream ins;

   public LoginInputstreamdecorator(InputStream ins) {
      this.ins = ins;
   }

   public int read() throws IOException {
      return ins.read();
   }

   public void close() throws IOException {
      ins.close();
   }
}