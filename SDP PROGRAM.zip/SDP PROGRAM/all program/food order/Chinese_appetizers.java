public class Chinese_appetizers implements appetizers{
    public String create_appetizers()
    {
        return "create Chinese appetizers dish";
    }
}