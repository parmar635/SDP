public class linuxbtn implements button {
    public void createButton()
    {
        System.out.println("Button of linux");
    }
  
}
