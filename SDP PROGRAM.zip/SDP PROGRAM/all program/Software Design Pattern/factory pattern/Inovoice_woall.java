public class Inovoice_woall implements Inovoice{
    String Itype;
   
   public Inovoice_woall()
   {
    Itype="Inovoice with header and Footer..";
   }
   public String getInovoice()
   {
      return Itype;
   }
}
