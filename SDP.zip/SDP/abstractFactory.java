public abstract class  abstractFactory {
     public abstract button getBtn();
     public abstract radiobutton getRbtn();
     public abstract checkBox getchk();
    
     public static abstractFactory getComponet(String os)
     {
           switch (os) {
               case "window":
                    return new windowFactory();
                
               case "linux":
                    return new linuxFactory();
                   
               case "mac":
                    return new macFactory();
                    
           
               default:
                    break;
           }
                     return null;
           
     }
}
