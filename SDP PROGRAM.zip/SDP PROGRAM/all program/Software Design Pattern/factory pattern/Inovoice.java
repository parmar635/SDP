public interface Inovoice {
 
    public String getInovoice();
}