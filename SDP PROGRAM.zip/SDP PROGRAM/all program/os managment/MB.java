public class MB implements Button{
    public String createButton()
    {
      return "create mac button";
    }  
}