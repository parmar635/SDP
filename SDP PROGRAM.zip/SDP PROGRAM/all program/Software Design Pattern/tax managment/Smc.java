public class Smc implements PropertyTax,WaterTax{
    public void CalculateTax()
    {
        System.out.println("smc taxcalculate");
    }
}
