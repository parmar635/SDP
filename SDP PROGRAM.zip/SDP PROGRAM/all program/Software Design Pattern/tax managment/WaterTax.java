public interface WaterTax {
    public void CalculateTax();
}
