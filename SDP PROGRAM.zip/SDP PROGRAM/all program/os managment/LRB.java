public class LRB  implements RadioButton{
    public String createRadioButton()
    {
        return "create linux Radiobutton";
    }
}
