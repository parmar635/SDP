public class windowrbtn implements radiobutton{
    public void createRadio()
    {

        System.out.println("radioButton of window");
    }
    
}
