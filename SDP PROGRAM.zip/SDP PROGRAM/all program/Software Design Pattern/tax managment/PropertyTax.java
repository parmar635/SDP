public interface PropertyTax {
     public void CalculateTax();
}