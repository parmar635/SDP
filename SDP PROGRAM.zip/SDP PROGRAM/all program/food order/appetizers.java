public interface appetizers {
    public String create_appetizers();
}
