public class maxtwoclass {
    private static int instanceCount = 0;
    private static final int MAX_INSTANCES = 2;


    private maxtwoclass() {
        instanceCount++;
    }


    public static maxtwoclass createInstance() throws Exception {
        if (instanceCount >= MAX_INSTANCES) {
            throw new Exception("Cannot create more than two instances of this class.");
        }
        return new maxtwoclass();
    }


    @Override
    protected void finalize() throws Throwable {
        super.finalize();
        instanceCount--;
    }

    public static void main(String[] args) {
        try {
            maxtwoclass obj1 = maxtwoclass.createInstance();
            System.out.println("First instance created.");

            maxtwoclass obj2 = maxtwoclass.createInstance();
            System.out.println("Second instance created.");


            maxtwoclass obj3 = maxtwoclass.createInstance();
            System.out.println("Third instance created.");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
