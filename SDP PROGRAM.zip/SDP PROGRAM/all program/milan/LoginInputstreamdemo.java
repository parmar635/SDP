import java.io.IOException;
import java.io.InputStream;

public class LoginInputstreamdemo extends LoginInputstreamdecorator {
    public int bytecount = 0;
    public int worldcount = 0;
    public int linecount = 0;

    public LoginInputstreamdemo(InputStream ins) {
        super(ins);
    }

    public int read() throws IOException {
        int data = ins.read();
        bytecount++;
        if (data == 32) {
            worldcount++;
        }
        if (data == 10) {
            worldcount++;
            linecount++;
        }
        return data;
    }

    public void close() throws IOException {
        ins.close();
    }

    public int countcharacter() {
        return bytecount;
    }

    public int countword() {
        return worldcount;
    }

    public int countline() {
        return linecount;
    }

}
