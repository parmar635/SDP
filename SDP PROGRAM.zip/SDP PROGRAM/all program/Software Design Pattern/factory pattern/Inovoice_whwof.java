public class Inovoice_whwof implements Inovoice {
    String Itype;
   
   public Inovoice_whwof()
   {
    Itype="Inovoice with header without footer..";
   }
   public String getInovoice()
   {
      return Itype;
   }
}
