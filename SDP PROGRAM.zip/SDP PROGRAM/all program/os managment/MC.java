public class MC implements checkbox{
    public String createcheckbox()
    {
        return "create mac checkbox";
    }
}