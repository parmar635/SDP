public class WC implements checkbox{
    public String createcheckbox()
    {
        return "create Window checkbox";
    }
}