class Inovoice_wall implements Inovoice{
   String Itype;
   
   public Inovoice_wall()
   {
    Itype="Inovoice with all..";
   }
   public String getInovoice()
   {
      return Itype;
   }
}
