public class macrbtn implements radiobutton {

    public void createRadio()
    {
        System.out.println("radioButton  of Mac");
    }
}