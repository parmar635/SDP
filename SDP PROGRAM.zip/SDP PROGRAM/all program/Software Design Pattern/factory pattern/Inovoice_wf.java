public class Inovoice_wf implements Inovoice{
    String Itype;
   
   public Inovoice_wf()
   {
    Itype="Inovoice without Footer..";
   }
   public String getInovoice()
   {
      return Itype;
   }
}
