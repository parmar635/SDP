public class MRB implements RadioButton {
    public String createRadioButton()
    {
        return "create mac Radiobutton";
    }
}