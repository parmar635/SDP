
public class Main {
    public static void main(String[] args) {
        
        Inovoice inv=Foctory.getInovoicetype();
		System.out.println(inv.getInovoice());
    }
}
