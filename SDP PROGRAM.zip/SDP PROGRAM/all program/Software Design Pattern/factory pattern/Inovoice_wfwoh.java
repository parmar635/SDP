public class Inovoice_wfwoh implements Inovoice {
    String Itype;
   
   public Inovoice_wfwoh()
   {
    Itype="Inovoice with Footer without header..";
   }
   public String getInovoice()
   {
      return Itype;
   }
}
