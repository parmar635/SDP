public class windowFactory extends abstractFactory{
    public  button getBtn()
    {
        return new windowbtn();
    }
    public  radiobutton getRbtn()
    {
        return new windowrbtn();
    }
    public checkBox getchk()
    {
        return new windowchk();
    }
}
