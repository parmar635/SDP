public class WRB implements RadioButton{
    public String createRadioButton()
    {
        return "create window Radiobutton";
    }
}
