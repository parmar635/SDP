public class icrem {

     public static void main(String[] args) {
        System.err.println("this is vanila icream");
     }
}