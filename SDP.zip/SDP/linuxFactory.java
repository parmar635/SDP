public class linuxFactory extends abstractFactory{
    public  button getBtn()
    {
        return new linuxbtn();
    }
    public  radiobutton getRbtn()
    {
        return new linuxrbtn();
    }
    public checkBox getchk()
    {
        return new linuxchk();
    }
}
