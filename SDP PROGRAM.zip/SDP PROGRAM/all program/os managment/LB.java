public class LB implements Button{
    public String createButton()
    {
      return "create linux button";
    }  
}
