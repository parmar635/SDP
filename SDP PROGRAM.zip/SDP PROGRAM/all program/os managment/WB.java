public class WB implements Button{
    public String createButton()
    {
      return "create window button";
    }  
}
