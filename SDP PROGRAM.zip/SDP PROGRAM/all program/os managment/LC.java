public class LC implements checkbox{
    public String createcheckbox()
    {
        return "create linux checkbox";
    }
}