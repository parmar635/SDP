import java.util.Scanner;

// Abstract Factory
interface CuisineFactory {
    Appetizer createAppetizer();
    MainCourse createMainCourse();
    Dessert createDessert();
}

// Product Interfaces
interface Appetizer {
    String getDishName();
}

interface MainCourse {
    String getDishName();
}

interface Dessert {
    String getDishName();
}

// Concrete Products for Indian Cuisine
class IndianAppetizer implements Appetizer {
    @Override
    public String getDishName() {
        return "Samosa";
    }
}

class IndianMainCourse implements MainCourse {
    @Override
    public String getDishName() {
        return "Dal Bati";
    }
}

class IndianDessert implements Dessert {
    @Override
    public String getDishName() {
        return "Gulab Jamun";
    }
}

// Concrete Products for Chinese Cuisine
class ChineseAppetizer implements Appetizer {
    @Override
    public String getDishName() {
        return "Spring Rolls";
    }
}

class ChineseMainCourse implements MainCourse {
    @Override
    public String getDishName() {
        return "Fried Rice";
    }
}

class ChineseDessert implements Dessert {
    @Override
    public String getDishName() {
        return "Mango Pudding";
    }
}

// Concrete Factory for Indian Cuisine
class IndianCuisineFactory implements CuisineFactory {
    @Override
    public Appetizer createAppetizer() {
        return new IndianAppetizer();
    }

    @Override
    public MainCourse createMainCourse() {
        return new IndianMainCourse();
    }

    @Override
    public Dessert createDessert() {
        return new IndianDessert();
    }
}

// Concrete Factory for Chinese Cuisine
class ChineseCuisineFactory implements CuisineFactory {
    @Override
    public Appetizer createAppetizer() {
        return new ChineseAppetizer();
    }

    @Override
    public MainCourse createMainCourse() {
        return new ChineseMainCourse();
    }

    @Override
    public Dessert createDessert() {
        return new ChineseDessert();
    }
}

// Client Code
public class MultiCuisineFoodOrderingSystem {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Multi-Cuisine Restaurant!");
        System.out.println("Please select a cuisine:");
        System.out.println("1. Indian");
        System.out.println("2. Chinese");
        System.out.print("Enter your choice (1 or 2): ");
        int cuisineChoice = scanner.nextInt();

        CuisineFactory factory = null;

        // Determine the selected cuisine
        if (cuisineChoice == 1) {
            factory = new IndianCuisineFactory();
            System.out.println("\nYou selected Indian Cuisine.");
        } else if (cuisineChoice == 2) {
            factory = new ChineseCuisineFactory();
            System.out.println("\nYou selected Chinese Cuisine.");
        } else {
            System.out.println("Invalid choice! Exiting.");
            return;
        }

        System.out.println("\nWhat would you like to order?");
        System.out.println("1. Appetizer");
        System.out.println("2. Main Course");
        System.out.println("3. Dessert");
        System.out.print("Enter your choice (1, 2, or 3): ");
        int dishChoice = scanner.nextInt();

        // Display the selected dish
        switch (dishChoice) {
            case 1:
                System.out.println("Your Appetizer: " + factory.createAppetizer().getDishName());
                break;
            case 2:
                System.out.println("Your Main Course: " + factory.createMainCourse().getDishName());
                break;
            case 3:
                System.out.println("Your Dessert: " + factory.createDessert().getDishName());
                break;
            default:
                System.out.println("Invalid choice! Exiting.");
        }

        scanner.close();
    }
}
